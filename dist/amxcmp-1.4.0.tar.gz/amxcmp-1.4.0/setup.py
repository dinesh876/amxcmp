# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['amxcmp']

package_data = \
{'': ['*']}

install_requires = \
['click>=8.0.4,<9.0.0', 'tqdm>=4.62.3,<5.0.0']

entry_points = \
{'console_scripts': ['amxcmp = amxcmp.cli:cli']}

setup_kwargs = {
    'name': 'amxcmp',
    'version': '1.4.0',
    'description': '',
    'long_description': None,
    'author': 'dinesh876',
    'author_email': 'dineshadventure15@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
